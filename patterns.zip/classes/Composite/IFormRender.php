<?php

namespace Composite;

interface IFormRender 
{
    public function render() : string;
}