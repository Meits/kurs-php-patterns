<?php
namespace Mediator;


class Data extends App 
{
    public function getData() 
    {
        return 'some data';
    }
}