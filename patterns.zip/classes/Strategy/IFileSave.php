<?php
namespace Strategy;

interface IFileSave
{
    public function save();
}