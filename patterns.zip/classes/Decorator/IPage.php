<?php
namespace Decorator;

interface IPage
{
    public function getTitle();
    public function render();
}