<?php
namespace Command;


class User 
{
    public function goOnLIne() {
        echo "User go onLine";
    }
    public function goOffLIne() {
        echo "User go offLine";
    }
}