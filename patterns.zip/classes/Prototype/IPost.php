<?php
namespace Prototype;

interface IPost 
{
    public function __clone();
}