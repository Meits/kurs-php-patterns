<?php
namespace StaticFabric;

interface IFactory {
    public function save();
}