<?php
namespace FabricMethod;

interface ISave 
{
    public function save($message);
}