<?php
namespace AbstractFactory;


interface DatabaseConnect
{
    public function connection();
}