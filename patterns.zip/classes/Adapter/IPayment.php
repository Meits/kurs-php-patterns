<?php

namespace Adapter;

interface IPayment 
{
    
}